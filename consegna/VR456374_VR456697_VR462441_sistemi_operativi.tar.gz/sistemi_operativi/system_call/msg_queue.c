/// @file msg_queue.c
/// @brief Contiene l'implementazione delle funzioni
///         specifiche per la gestione delle MESSAGE QUEUE.

#include "err_exit.h"
#include "msg_queue.h"