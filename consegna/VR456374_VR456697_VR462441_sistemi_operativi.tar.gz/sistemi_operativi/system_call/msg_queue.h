/// @file msg_queue.h
/// @brief Contiene la definizioni di variabili e
///         funzioni specifiche per la gestione delle message queue.

#pragma once

#include <sys/msg.h>

#define MSG_QUEUE_KEY 52136